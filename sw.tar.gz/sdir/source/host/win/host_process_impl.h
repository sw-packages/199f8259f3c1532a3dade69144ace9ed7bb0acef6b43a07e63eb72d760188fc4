//
// Aspia Project
// Copyright (C) 2018 Dmitry Chapyshev <dmitry@aspia.ru>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program. If not, see <https://www.gnu.org/licenses/>.
//

#ifndef HOST__WIN__HOST_PROCESS_IMPL_H
#define HOST__WIN__HOST_PROCESS_IMPL_H

#include <QPointer>
#include <QString>
#include <QWinEventNotifier>

#include "base/win/scoped_object.h"
#include "host/win/host_process.h"

namespace host {

class HostProcessImpl
{
public:
    explicit HostProcessImpl(HostProcess* process);
    ~HostProcessImpl();

    void startProcess();
    void killProcess();
    void terminateProcess();

    bool startProcessWithToken(HANDLE token);

    HostProcess* process_;
    HostProcess::ProcessState state_ = HostProcess::NotRunning;
    HostProcess::Account account_ = HostProcess::User;
    uint32_t session_id_ = -1;
    QString program_;
    QStringList arguments_;

    base::win::ScopedHandle thread_handle_;
    base::win::ScopedHandle process_handle_;
    uint32_t process_id_ = -1;
    uint32_t thread_id_ = -1;

    QPointer<QWinEventNotifier> finish_notifier_;

    DISALLOW_COPY_AND_ASSIGN(HostProcessImpl);
};

} // namespace host

#endif // HOST__WIN__HOST_PROCESS_IMPL_H
